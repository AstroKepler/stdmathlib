# stdmathlib

A Python library to simplify mathematical computations.

## Installation

```bash
pip install stdmathlib